'use strict';
var AWS = require('aws-sdk');
const S3 = require('aws-sdk/clients/s3');
const s3 = new S3({
  apiVersion: '2006-03-01',
  region: process.env.AWSREGION
});

var lambda = new AWS.Lambda();



//const DynamoDB = require('aws-sdk/clients/dynamodb');
//const DocumentClient = new DynamoDB.DocumentClient({
 // apiVersion: '2012-08-10',
//  region: process.env.AWSREGION
//});
function buildResponse() {
  return {
    lambdaResult: "Succeeded"
  }
}
const simpleParser = require('mailparser').simpleParser;

const uuid = require('uuid/v4');

module.exports.handler = async (event, context, callback) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  const record = event.Records[0];

  // 1. Retrieve the email from your bucket
  const request = {
    Bucket: record.s3.bucket.name,
    Key: decodeURIComponent(record.s3.object.key)
  };

  try {
    const data = await s3.getObject(request).promise();

    // 2. Parse email
   // console.log('Raw email:' + data.Body);
    const email = await simpleParser(data.Body);
    //console.log('changed Raw email:' + email)
    console.log('email:', JSON.stringify(email));
    console.log('date:', email.date);
    console.log('subject:', email.subject);
    console.log('body:', email.text);
    console.log('from:', email.from.text);
    console.log('attachments:', email.attachments);
    console.log('checkpoint1');
    console.log('bucketname:', request.Bucket),
    console.log('key:', request.Key);
    console.log('checkpoint2');
    console.log('id:', uuid());
    
    let dict = {};
    dict.email = email;
    dict.date = email.date;
    dict.subject=email.subject;
    dict.text=email.text;
    dict.from=email.from.text;
    dict.attachments=email.attachments;
    dict.to=email.to.text;
    dict.bucketname=request.Bucket;
    dict.keyname=request.Key;
    dict.ID=uuid();
    
    
    console.log(JSON.stringify(dict))
    
    
    
    const params = {
      'FunctionName': 'SES_MIGRATION_TEST_LAMBDA_PYTHON2',/* required */
      'InvokeArgs': JSON.stringify(dict)
    };
    lambda.invokeAsync(params, function(err, data) {
      if (err) 
        throw (err);
        //console.log(err, err.stack); // an error occurred
        //console.log("theres an error")
      else  {  
        console.log(JSON.stringify(data));
        if (callback)
          callback(null, buildResponse());
        else
          console.log('nothing to callback');
      //console.log('hello from lambda b'+ data.Payload);           // successful response
      }
      });
      callback(null, buildResponse());
    console.log("successfully processed");
    console.log(params);

  /*  // 3. Store email to DDB
    let params = {
      TableName: 'EmailTable-' + process.env.STAGE,
      Item: {
        id: uuid(),
        bucket: request.Bucket,
        key: request.Key,
        createdAt: new Date(Date.now()).toISOString(),
        updatedAt: new Date(Date.now()).toISOString()
      }
    };

    email.from ? (params.Item.from = email.from.text) : null;
    email.to ? (params.Item.to = email.to.text) : null;
    email.subject ? (params.Item.subject = email.subject) : null;
    email.body ? (params.Item.body = email.text) : null;
    email.attachments ? (params.Item.attachments = email.attachments) : null;
    email.date ? (params.Item.date = email.date.toISOString()) : null;

    await DocumentClient.put(params).promise();*/

    // 4. Respond
   //return { status: 'success' };
  } catch (error) {
    console.log(error, error.stack);
    throw error;
  }
};
