import base64
import json
import boto3
import os
import datetime
def lambda_handler(event, context):
    
    print(event)
    #a= event['text']

    a= event.get('text','0000')
    print(a)
    if 'custID' in a:
        print('inside if')
        CustomerId = a[a.find('custID'):a[a.find('custID'):].find('&')+a.find('custID')]     # getting customerId from text field
    else:
        print('inside else')
        CustomerId = '0000'
        CustomerId=str(CustomerId)

    print(CustomerId,'this is without default customerid')   
    if CustomerId =='0000':
        print('inside second if')
        CustomerId=str(CustomerId)
        print(type(CustomerId),'this is typeof Customerid')
        
    else:
        print('inside seconf else')
        CustomerId=CustomerId.split('=')
        CustomerId=CustomerId[1]
        CustomerId=str(CustomerId)
        
    print(type(CustomerId),'this is STRING of Customerid')
    subject=event['subject']
    tomail=event['to']
    frommail=event['from']
    date=event['date']
    print(type(date),'this is daat type')
    attachments=str(event['attachments']).replace("\'",'\"')
    
    bucketname=event['bucketname']
    keyname=event['keyname']
    print(keyname,'this is keyname')
    ID=event['ID']
    #CustomerId='123456'
    createdAt=datetime.datetime.now()
    updatedAt=datetime.datetime.now()
    rdsData = boto3.client('rds-data')
    CLUSTER_ARN = os.environ['CLUSTER_ARN']
    SECRET_ARN = os.environ['SECRET_ARN']
    databasename= os.environ['DATABASE_NAME']
    print(createdAt,'this is createdAt query')
    SQL_QUERY='select max(ID) from ses_email_info_db.ses_email_info_table_migration;'  #To get the maximum ID valuefrom RDS
    def query(CLUSTER_ARN=CLUSTER_ARN,SECRET_ARN=SECRET_ARN,databasename=databasename,SQL_QUERY=SQL_QUERY):
        response = rdsData.execute_statement(
                resourceArn = CLUSTER_ARN, 
                secretArn = SECRET_ARN, 
                database = databasename, 
                sql = SQL_QUERY)
                
        return response
    
    a=query(SQL_QUERY=SQL_QUERY)
    print()
   
    if(a['records'][0][0]['longValue']):
        ID = a['records'][0][0]['longValue']+1
    else:
        ID = 1
        
    print('this is id',ID)
#---------------------------------------Insert query to insert all records into rds table---------------------------------
    SQL_QUERY="""INSERT INTO ses_email_info_db.ses_email_info_table_migration VALUES('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}');""".format(ID,attachments,bucketname,createdAt,updatedAt,date,keyname,subject,tomail,frommail,CustomerId);
    print('this is query',SQL_QUERY)
    #SQL_QUERY='show databases;'
    query(SQL_QUERY=SQL_QUERY)
    print('successfully inserted')
#---------------------------------------------------------------------------------------------
    
    
    
   



    
    
    